-- Status:3:0:MP_0:eventmanagement:php:1.24.4::5.6.16:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|access|0|16384||InnoDB
-- TABLE|event|0|32768||InnoDB
-- TABLE|participation|0|49152||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2015-03-27 11:51

--
-- Create Table `access`
--

DROP TABLE IF EXISTS `access`;
CREATE TABLE `access` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(300) NOT NULL,
  `password` varchar(100) NOT NULL,
  `access` int(11) DEFAULT '0',
  `code` varchar(10) NOT NULL DEFAULT '',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `access`
--

/*!40000 ALTER TABLE `access` DISABLE KEYS */;
/*!40000 ALTER TABLE `access` ENABLE KEYS */;


--
-- Create Table `event`
--

DROP TABLE IF EXISTS `event`;
CREATE TABLE `event` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `max_count` int(11) NOT NULL DEFAULT '10',
  `ptr2owner` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `ptr2owner` (`ptr2owner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `event`
--

/*!40000 ALTER TABLE `event` DISABLE KEYS */;
/*!40000 ALTER TABLE `event` ENABLE KEYS */;


--
-- Create Table `participation`
--

DROP TABLE IF EXISTS `participation`;
CREATE TABLE `participation` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ptr2accessid` bigint(20) unsigned NOT NULL,
  `ptr2eventid` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ptr2accessid` (`ptr2accessid`),
  KEY `ptr2eventid` (`ptr2eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data for Table `participation`
--

/*!40000 ALTER TABLE `participation` DISABLE KEYS */;
/*!40000 ALTER TABLE `participation` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

